import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../models/customer.model';
import { apiUrl } from './ApiUrl';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  apiUrl: string= apiUrl+"/api/customer";


  constructor(private httpClient:HttpClient) { 
  }
  
  public registerCustomer(customer: Customer): Observable<any>{
    return this.httpClient.post(this.apiUrl, customer);
  }

  public getCustomerById(customerId: number): Observable<any>{
    return this.httpClient.get(this.apiUrl+"/"+customerId);
  }

  public getCustomerByUserId(userId : number): Observable<any>{
    // return this.httpClient.get(this.apiUrl+"/customer/user/"+userId);
    return this.httpClient.get(this.apiUrl+"/user/"+userId);
  }

  public getAllCustomers(): Observable<any>{
    return this.httpClient.get(this.apiUrl);
  }
}
