import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { Router } from '@angular/router';

import { Logindto } from '../models/logindto.model';
import { apiUrl } from './ApiUrl';
import { Global } from '../resources/global';
import { Loginresponsedto } from '../models/loginresponsedto.model';

@Injectable({
  providedIn: 'root'
  
})
export class AuthService {

   apiUrl:String=apiUrl;


  constructor(private httpClient:HttpClient,private router:Router) { }
  
  
 public  register(user:User):Observable<any> {    
    return this.httpClient.post(this.apiUrl+"/api/register",user);
  
  }
  
  
  public login(user : Logindto,callback : any){
    this.httpClient.post(Global.apiUrl+"/api/login",user).subscribe((data : Loginresponsedto)=>{
      localStorage.setItem("jwttoken",data.jwtToken);
      localStorage.setItem("username", data.username);
      localStorage.setItem("userId",data.userId+"");
      localStorage.setItem("role", data.role);
      console.log("Login successful");
      alert("Login Successfull");
      console.log(data);
      if(data.role == "ADMIN")
        this.router.navigate(['/api/specs/view'])
      else
        this.router.navigate([`/customer/specs/${data.userId}`]);
      callback(true);
    },error =>{
      callback(false);
    });
  }

  public isLoggedIn() : boolean {
    let jwttoken = localStorage.getItem("jwttoken")
    if(jwttoken == null || jwttoken == undefined)
      return false;
    else
      return true;
  }

  getUserById(userId: number):Observable<any>{
    return this.httpClient.get(this.apiUrl+"/api/user/"+userId);
    
  }

}

  