import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { useAnimation } from '@angular/animations';
import { Order } from '../models/order.model';
import { apiUrl } from './ApiUrl';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private httpClient:HttpClient) { }


  apiUrl:string = apiUrl;


  public addOrder(order : Order , customerId :number):Observable<any>{
    return this.httpClient.post(this.apiUrl+"/api/order/"+customerId,order);

  }
  public viewAllOrders():Observable<any>{
    return this.httpClient.get(this.apiUrl+"/api/order");
  }
  public getOrderby_userId(userId:number):Observable<any>{
    console.log("userId : "+userId);
    return this.httpClient.get(this.apiUrl+"/api/order/user/"+userId);

  }

  public addOrderByUserId(UserId :number,order : Order):Observable<any>{
    return this.httpClient.post( this.apiUrl+"/api/order/user/"+UserId,order);

  }


}
