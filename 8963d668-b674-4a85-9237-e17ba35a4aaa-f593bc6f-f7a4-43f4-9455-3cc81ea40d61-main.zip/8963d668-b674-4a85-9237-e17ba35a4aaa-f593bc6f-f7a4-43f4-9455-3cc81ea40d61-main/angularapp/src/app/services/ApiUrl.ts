
export const apiUrl = 'https://ide-fececdfeddcadeabbdeceaafdfbcffafccead.premiumproject.examly.io/proxy/8080'



