import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cart } from '../models/cart.model';
import { Specs } from '../models/specs.model';
import { apiUrl } from './ApiUrl';
import { Review } from '../models/review.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  customerId :number=0;

  apiUrl:string = apiUrl + "/api";



  updateCart(cartDetails : Cart):Observable<Cart>{
    return this.httpClient.put(this.apiUrl+"/cart/"+cartDetails.cartId,cartDetails);
  }

  getAllSpecsFromCart() : Observable<Specs[]> {
    return this.httpClient.get(this.apiUrl+"/cart/customer/"+this.customerId) as Observable<Specs[]>;
  }

  getCartByUserId(userId : number):Observable<Cart>{

    return this.httpClient.get(this.apiUrl+"/cart/user/"+userId);
  }

  addCart(cart : any):Observable<Cart>{
    console.log(cart);
    return this.httpClient.post(this.apiUrl+"/cart",cart);
  }

  addSpecsToCart(cartId : number,specsId : number){
    return this.httpClient.post(this.apiUrl+"/cart/"+cartId+"/specs/"+specsId,null);
  }

  removeSpecsFromCart(cartId : number,specsId :number):Observable<any>{
    return this.httpClient.delete(this.apiUrl+"/cart/"+cartId+"/specs/"+specsId);
  }

  removeAllSpecsFromCart(cartId:number){
    return this.httpClient.delete(this.apiUrl+"/cart/"+cartId)
  }

  addReview(review:any, customerId: number){
    console.log("in review service");
    console.log(review.specs[0]);
    // console.log(JSON.stringify(review.specs));
    return this.httpClient.post(this.apiUrl+"/review/"+customerId,review);
  }

  getAllReviews():Observable<Review[]> {
    return this.httpClient.get(this.apiUrl+"/review") as Observable<Review[]>;

  }

  getReviewsBySpecs(specsId: number) :Observable<Review[]> {
    console.log("this is cart service"+specsId);
    return this.httpClient.get(this.apiUrl+"/spec/review/"+specsId) as Observable<Review[]> ;
  }

  removeSpecs(specsId:number){
    return this.httpClient.delete(this.apiUrl+"/cart/specs/"+specsId);
  }

  constructor(private httpClient : HttpClient) { }
}