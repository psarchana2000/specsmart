import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Specs } from '../models/specs.model';
import { apiUrl } from './ApiUrl';

@Injectable({
  providedIn: 'root'
})
export class SpecsService {

  apiUrl : string =apiUrl+"/api/specs";

  constructor(private httpClient:HttpClient) { }

  public addSpecs(specs:any) :Observable<any>{
    return this.httpClient.post(this.apiUrl,specs);
  }

  public viewAllSpecs() : Observable<Specs[]>{
    return this.httpClient.get(this.apiUrl) as Observable<Specs[]>;
  }

  public viewSpecsByID(specsId:any) : Observable<any>{
    return this.httpClient.get(this.apiUrl+"/"+specsId);
  } 

  public updateSpecs(specsId:number,updatedSpecs:Specs) :Observable<any>{
    return this.httpClient.put(this.apiUrl+"/"+specsId,updatedSpecs);
  }

  public deleteSpecs(specsId:any) : Observable<any>{
    return this.httpClient.delete(this.apiUrl+"/"+specsId);
  }

}