export interface Loginresponsedto {
    userId ?: number;
    jwtToken ?: string;
    username ?: string;
    role ?: string;
}