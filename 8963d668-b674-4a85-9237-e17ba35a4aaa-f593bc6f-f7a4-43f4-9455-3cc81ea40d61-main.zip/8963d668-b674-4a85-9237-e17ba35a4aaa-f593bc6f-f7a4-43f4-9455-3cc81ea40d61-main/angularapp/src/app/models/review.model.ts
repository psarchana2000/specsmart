
import { Customer } from "./customer.model";
import { Specs } from "./specs.model";

export interface Review {
   reviewId?:number;
   customer?:Customer;
   subject?:string;
   body?:String;
   rating?:number;
   dateCreated?:Date;
   specs?: Specs;

}
