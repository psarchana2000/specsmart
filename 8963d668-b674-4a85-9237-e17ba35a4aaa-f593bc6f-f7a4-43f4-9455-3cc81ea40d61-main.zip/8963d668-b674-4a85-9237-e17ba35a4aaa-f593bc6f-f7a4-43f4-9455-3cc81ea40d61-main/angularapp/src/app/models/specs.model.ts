export interface Specs {
    specsId ?: number,
    name ?: string,
    category ?: string,
    imageUrl ?: string,
    description ?: string,
    price ?: number,
    quantity ?: number
}
