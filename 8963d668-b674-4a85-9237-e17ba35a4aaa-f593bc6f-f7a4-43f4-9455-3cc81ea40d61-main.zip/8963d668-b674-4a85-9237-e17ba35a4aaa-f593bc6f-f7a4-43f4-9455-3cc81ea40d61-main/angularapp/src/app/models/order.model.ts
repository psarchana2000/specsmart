import { Customer } from "./customer.model";
import { Specs } from "./specs.model";


export interface Order {

   orderId ?: number,
   orderPrice ?: number,
   quantity ?: number,
   customer ?: Customer,
   specs ?: Specs[],
   orderDate ?: Date 

} 







