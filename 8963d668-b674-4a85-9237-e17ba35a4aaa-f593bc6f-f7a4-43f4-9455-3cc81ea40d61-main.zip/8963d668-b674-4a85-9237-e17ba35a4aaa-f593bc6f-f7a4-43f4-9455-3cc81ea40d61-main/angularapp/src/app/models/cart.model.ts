import { Customer } from "./customer.model";
import { Specs } from "./specs.model";

export interface Cart {
    cartId ?: number,
    specs ?: Specs[],
    customer ?: Customer,
    totalAmount ?: number
}
