import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Cart } from 'src/app/models/cart.model';
import { Customer } from 'src/app/models/customer.model';
import { Order } from 'src/app/models/order.model';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { CustomerService } from 'src/app/services/customer.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {
        userId : number =0;
        customer : Customer = {};
        order:Order = {};
        cart : Cart = {}; 
        orders : Order[] = [];

        
        ngOnInit(): void {
          this.userId = this.activatedRoute.snapshot.params['id'];
          this.getCartByUserId();
        }



        getCartByUserId(){
          this.cartService.getCartByUserId(this.userId).subscribe(data => {
            this.cart = data;
            console.log(data);
            console.log(this.cart);

            // this.order.customer = {...this.cart.customer};
            // console.log( "Order---------------------------- : ");
            
            // this.order.orderPrice = this.cart.totalAmount;
            // this.order.specs = this.cart.specs;
            // this.order.quantity = this.order.specs.length;

            // console.log(this.order);


            // this.customerService.getCustomerByUserId(this.userId).subscribe(data => {
            //   this.customer = data;
            //   console.log("get customer by user");
            //   console.log(this.customer);
              this.getOrder();
            // });
          })
        }
        
        getOrder(){
          this.service.getOrderby_userId(this.userId).subscribe(data => {
            this.orders = data;
            console.log("Order object retrived succesffully.");
            console.log(data);
            this.order = this.orders[this.orders.length-1];
          });
        }

        constructor(private service:OrderService,private customerService : CustomerService,private cartService : CartService,private activatedRoute : ActivatedRoute) { 
          
        }

        makePayment(){
          let message: string = "Payment Completed"; 
          alert(message);

        }

        

        


}