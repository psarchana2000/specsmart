import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Review } from 'src/app/models/review.model';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { SpecsService } from 'src/app/services/specs.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-review',
  templateUrl: './view-review.component.html',
  styleUrls: ['./view-review.component.css']
})
export class ViewReviewComponent implements OnInit {

  averageRating:number;
  totalRating:number = 0;
  ratingCount: number = 0;
  specId: number;
  spec : Specs;
  reviews :Review[]=[];
  role : string = localStorage.getItem('role');
  
  constructor(private cartService: CartService,private specService:SpecsService, private activatedRoute : ActivatedRoute) { }

  ngOnInit(): void {
    this.specId = parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    console.log(this.specId);
    this.specService.viewSpecsByID(this.specId).subscribe(data=>{
      this.spec = data;
    })
    this.getReviewsBySpecs(this.specId);
     
    
  }

  public getReviewsBySpecs(specId: number){
    this.cartService.getReviewsBySpecs(specId).subscribe(data => {
      console.log(""+data); 
      this.reviews = data;
      this.findAverageRating();  
    })
  }

  public getAllReviews(){
    this.cartService.getAllReviews().subscribe(data=>{
      this.reviews = data;
      console.log("review list working");
      console.log(this.reviews);
    })
  }

  public findAverageRating(){
    // this.cartService.getReviewsBySpecs(specId).subscribe(data=>{
    //   this.reviews = data;
    // })
    if(this.reviews.length != 0){
      for(let r of this.reviews){
        this.ratingCount = this.ratingCount + 1;
        this.totalRating = this.totalRating + r.rating;
      }
      this.averageRating = this.totalRating/this.ratingCount ;
      this.averageRating =  Number(this.averageRating.toFixed(2));
      console.log("rating count:" + this.ratingCount);
      console.log("total rating:" + this.totalRating);
    }
    
  }
}

















































































































































































































































































































































































