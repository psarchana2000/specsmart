import { Component} from '@angular/core';

import { FormBuilder, FormGroup } from '@angular/forms';

import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {

  form : FormGroup;
  errorMessage : boolean = false;

  constructor(private fb : FormBuilder,private authService : AuthService) { 
    this.form = fb.group({
      username : fb.control(""),
      password : fb.control("")
    })

  }

  
  public onSubmit(){
    console.log(this.form.value);
    this.authService.login(this.form.value,(returnFlag : boolean)=>{
      this.errorMessage = !returnFlag;
    })
  }

}

