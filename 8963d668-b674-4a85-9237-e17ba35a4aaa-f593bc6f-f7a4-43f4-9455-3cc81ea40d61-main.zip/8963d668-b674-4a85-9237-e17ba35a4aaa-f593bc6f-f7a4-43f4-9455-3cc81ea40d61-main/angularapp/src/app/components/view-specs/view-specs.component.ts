import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { SpecsService } from 'src/app/services/specs.service';

@Component({
  selector: 'app-view-specs',
  templateUrl: './view-specs.component.html',
  styleUrls: ['./view-specs.component.css']
})
export class ViewSpecsComponent implements OnInit {

  specs : Specs[];
  newSpecs : Specs[];
  currentSpecId: number;
  currentSpec: Specs
  specsById : Specs;
 

  constructor(private specsService: SpecsService, private cartService: CartService, private router: Router) { }

  ngOnInit(): void {
    this.viewAllSpecs();
    
  }

  sortByPrice(sortBy : number){
    console.log(sortBy);
    if(sortBy == 1){
      this.specs = this.newSpecs.sort((s1,s2) => {
        if(s1.price > s2.price){
            return 1;
        }else if(s1.price < s2.price){
          return -1;
        }else{
          return 0;
        }
      })
    }else if(sortBy == 2){
      this.specs = this.newSpecs.sort((s1,s2) => {
        if(s1.price < s2.price){
            return 1;
        }else if(s1.price > s2.price){
          return -1;
        }else{
          return 0;
        }
      })

    }else{
      console.log(this.newSpecs);
      this.viewAllSpecs();
    }

  }

  public viewAllSpecs(){
    this.specsService.viewAllSpecs().subscribe(data=>{
      this.specs=data;
      this.newSpecs = data;
    })
  }
  

  public deleteSpecs(specsId:any){
      console.log("before");
        this.specsService.deleteSpecs(specsId).subscribe(data=>{
          this.viewAllSpecs();
          alert("Specs Deleted Successfully!");    
      }, error => {
        alert("Specs Already ordered.");
      });
  }

  public getCurrentSpec(specId:number){
    this.specsService.viewSpecsByID(specId).subscribe(data=>{
      this.currentSpec = data;
    })
  }

  public viewReview(specId: number){
    this.router.navigate(["/spec/review/"+specId]);
  }


}
