import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from 'src/app/models/cart.model';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private cartService : CartService,private router : Router) { }

  role:string="";

  userId : number=0;
  cartId : number=0;

  ngOnInit(): void {
    this.getUser();
   
  }

  // getCartByUserId(){
  //   console.log("In getCartUserId method")
  //   this.cartService.getCartByUserId(this.userId).subscribe(data => {
  //     this.cart  = data;
  //     console.log(this.cart);
      
  //   })
  // }

  getUser(){
    this.userId = parseInt(localStorage.getItem('userId'));
    this.role = localStorage.getItem('role');
    console.log("Role:" + this.role);
    console.log("UserId:" + this.userId);
  }

  logout(){
    console.log("logout");
    localStorage.removeItem("jwttoken");
      localStorage.removeItem("username");
      localStorage.removeItem("userId");
      localStorage.removeItem("role");
    this.router.navigateByUrl('/login');
  }


}
