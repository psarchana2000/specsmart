import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  role:string="";

  userId : number=0;

  constructor(private router : Router) { }

  ngOnInit(): void {
    this.getUser();
  }

  getUser(){
    this.userId = parseInt(localStorage.getItem('userId'));
    this.role = localStorage.getItem('role');
    console.log("Role:" + this.role);
    console.log("UserId:" + this.userId);
  }

  toLogin(){
    if(this.role == 'ADMIN'){
      this.router.navigateByUrl('/api/specs/view');
    }else if(this.role == 'CUSTOMER'){
      this.router.navigateByUrl('/customer/specs/'+this.userId);
    }else{
      this.router.navigateByUrl('/login');
    }
  }

}
