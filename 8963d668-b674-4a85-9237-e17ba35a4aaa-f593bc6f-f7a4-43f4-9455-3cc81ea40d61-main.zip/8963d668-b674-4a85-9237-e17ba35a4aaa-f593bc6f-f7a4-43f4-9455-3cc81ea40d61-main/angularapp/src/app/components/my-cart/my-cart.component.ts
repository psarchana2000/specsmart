import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from 'src/app/models/cart.model';
import { Order } from 'src/app/models/order.model';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-my-cart',
  templateUrl: './my-cart.component.html',
  styleUrls: ['./my-cart.component.css']
})
export class MyCartComponent implements OnInit {

  userId : number = 0;
  customerId : number = 0;
  order : Order={};

  specs : Specs[] = [];
  cart : Cart = {
    cartId : 0,
    specs : [] ,
    customer : null,
    totalAmount : 0
  };

  getSpecsFromCart(){
    this.cartService.getAllSpecsFromCart().subscribe(data => {
      this.specs = data;
    })
  }

  getCartByUserId(){
    this.cartService.getCartByUserId(this.userId).subscribe(data => {
      this.cart = data;
      console.log("Cart retrive Object : "+JSON.stringify(this.cart));
    })
  }

  placeOrder(){
      this.router.navigateByUrl('/place-order/'+this.userId);
      this.order.customer = {...this.cart.customer};
            console.log( "Order---------------------------- : ");
            
            this.order.orderPrice = this.cart.totalAmount;
            this.order.specs = this.cart.specs;
            this.order.quantity = this.order.specs.length;
            this.order.orderDate = new Date();

            this.orderService.addOrder(this.order,this.cart.customer.customerId).subscribe(data => {
              this.order = data;
              console.log("Order Created");
              console.log(data);
              this.cartService.removeAllSpecsFromCart(this.cart.cartId).subscribe(data => {
                console.log("removed all Specs from cart");
              })
            });
  }

  removeSpecsFromCart(specs:Specs){
    console.log(specs.specsId);
    this.cartService.removeSpecsFromCart(this.cart.cartId,specs.specsId).subscribe(data => {
      console.log("Specs Deleted successfully ");
      alert("removed from the cart.");
      this.getCartByUserId();
    })
  }

  constructor(private cartService : CartService, 
    private router : Router,
    private activatedRoute : ActivatedRoute,
    private orderService : OrderService
    ) { }

  ngOnInit(): void {
    this.userId = this.activatedRoute.snapshot.params['id'];
    this.getCartByUserId();

  }

}
