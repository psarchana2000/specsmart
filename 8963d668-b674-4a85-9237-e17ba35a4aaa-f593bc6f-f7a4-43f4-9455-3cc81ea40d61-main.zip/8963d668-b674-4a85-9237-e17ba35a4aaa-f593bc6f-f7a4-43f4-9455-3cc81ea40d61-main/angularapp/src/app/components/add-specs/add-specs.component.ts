import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Specs } from 'src/app/models/specs.model';
import { SpecsService } from 'src/app/services/specs.service';

@Component({
  selector: 'app-add-specs',
  templateUrl: './add-specs.component.html',
  styleUrls: ['./add-specs.component.css']
})
export class AddSpecsComponent  {

  specsForm : FormGroup;
  specs:Specs;

  
  constructor(private specsService:SpecsService, private builder : FormBuilder) {
    this.specsForm=builder.group({
      name : builder.control("",Validators.required),
      category : builder.control("",Validators.required),
      description : builder.control("",Validators.required),
      price : builder.control("",Validators.required),
      quantity : builder.control("",Validators.required),
      imageUrl : builder.control("",Validators.required)
    })
   }

  
  public addSpecs(){
    if(this.specsForm.valid){
      this.specs=this.specsForm.value;
      this.specsService.addSpecs(this.specs).subscribe(data=>{
        this.specsForm.reset();
        alert("Specs Added Successfully!");
      })
    }
  }

  public get name(){
    return this.specsForm.get("name");
  }
  public get category(){
    return this.specsForm.get("category");
  }
  public get description(){
    return this.specsForm.get("description");
  }
  public get price(){
    return this.specsForm.get("price");
  }
  public get quantity(){
    return this.specsForm.get("quantity");
  }
  public get imageUrl(){
    return this.specsForm.get("imageUrl");
  }
}
// name : string,
//     category : string,
//     imageUrl : string,
//     description : string,
//     price : string,
//     quantity : number
