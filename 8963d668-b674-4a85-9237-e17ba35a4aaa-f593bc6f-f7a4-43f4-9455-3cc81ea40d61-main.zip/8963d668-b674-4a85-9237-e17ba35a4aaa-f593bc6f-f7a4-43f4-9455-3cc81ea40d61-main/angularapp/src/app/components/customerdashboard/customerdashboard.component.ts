import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from 'src/app/models/cart.model';
import { Customer } from 'src/app/models/customer.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-customerdashboard',
  templateUrl: './customerdashboard.component.html',
  styleUrls: ['./customerdashboard.component.css']
})
export class CustomerdashboardComponent implements OnInit {

  userId: number;
  user: User;
  cart : Cart={};

customerRegistrationForm:FormGroup;
  constructor(private builder: FormBuilder, 
    private customerService : CustomerService,
    private activatedRoute: ActivatedRoute,
    private router : Router, 
    private cartService : CartService,
    private authService: AuthService) { 

    this.customerRegistrationForm = builder.group({
      customerName:this.builder.control("", Validators.required),
      address:this.builder.control("", Validators.required)
    })
  }

  ngOnInit(): void {
    this.userId = parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    console.log("user Id : "+ this.userId);
     this.authService.getUserById(this.userId).subscribe(data=>{
      console.log("in get user by id");
      this.user = data;
      console.log(data);
      console.log("after get user by id");
     });
  }

  public addCustomer(){
    let customer: Customer = this.customerRegistrationForm.value;
    customer.user = this.user;
    console.log(this.user);
    this.customerService.registerCustomer(customer).subscribe(data=>{
      console.log(data);
      this.cart.customer = data;
      this.cartService.addCart(this.cart).subscribe(data2 => {
        console.log("cart object after adding");
        console.log(data2);
        this.router.navigateByUrl('/login');
      });

    })
  }
}
