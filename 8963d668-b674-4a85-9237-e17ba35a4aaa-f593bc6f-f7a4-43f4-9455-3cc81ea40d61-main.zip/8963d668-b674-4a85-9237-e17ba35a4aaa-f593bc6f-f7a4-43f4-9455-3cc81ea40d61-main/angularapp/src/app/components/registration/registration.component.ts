import { Component} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent  {

  
registerForm : FormGroup;

user:User={username:'',email:'',password:'',mobileNumber:'',role:''}

  constructor(private service:AuthService,private builder:FormBuilder,private rout:Router) {
    this.registerForm=builder.group({
     username:builder.control("",Validators.required),
     email:builder.control("",[Validators.required,Validators.email]),
     password:builder.control("",[Validators.required,Validators.pattern(/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{8,}$/)]),
     confirmPassword:builder.control("",Validators.required),
     mobileNumber:builder.control("",[Validators.required,Validators.pattern('^[0-9]{10}$')]),
     role:builder.control("",Validators.required)
    },{ validator: this.confirmPasswordValidator })
   }
   

   confirmPasswordValidator(form:FormGroup):ValidationErrors | null{
    const pass = form.get('password')?.value
    const cfpass = form.get('confirmPassword')?.value
    return cfpass !== pass ? { mismatch:true }:null ;
   }

   register(){
    this.user.username=this.registerForm.get('username').value;
    this.user.email=this.registerForm.get('email').value;
    this.user.password=this.registerForm.get('password').value;
    this.user.mobileNumber=this.registerForm.get('mobileNumber').value;
    this.user.role=this.registerForm.get('role').value;
    this.service.register(this.user).subscribe(data => {
      console.log(data);
       

      if(this.user.role == "CUSTOMER"){
        console.log(data.userId);
        this.rout.navigate(['/customerdashboard/'+data.userId]);
      }else{

         this.rout.navigate(['/login']);

      }

    })

   

   }
}
