import { DatePipe, formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from 'src/app/models/customer.model';
import { Review } from 'src/app/models/review.model';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { CustomerService } from 'src/app/services/customer.service';
import { SpecsService } from 'src/app/services/specs.service';



@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.css']
})
export class AddReviewComponent implements OnInit {
  date: Date;
  specs: Specs;
  currentSpec: Specs;
  specId : number;
  specList: Specs[]=[];
  customer: Customer;
  customerId: number;
  userId : number = parseInt(localStorage.getItem('userId'));
  
  stars: number[] = [1, 2, 3, 4, 5];
  selectedValue: number = 0;
  addReviewForm: FormGroup;
  constructor(private builder: FormBuilder, private cartService: CartService, private activatedRoute : ActivatedRoute,private router : Router, private customerService: CustomerService, private specService: SpecsService) {
    this.addReviewForm = this.builder.group({
      // specs: this.builder.control("", Validators.required), 
      body: this.builder.control("", Validators.required),
      rating: this.builder.control("", Validators.required)
    })
  }

  ngOnInit(): void {
    this.specId = this.activatedRoute.snapshot.params['id'];
  
    this.customerService.getCustomerByUserId(this.userId).subscribe(data=>{
      this.customer = data;
      console.log("this is customer:"+ this.customer.customerId);
    })

    // this.specService.viewAllSpecs().subscribe(data=>{
    //   this.specList = data;
    //   console.log("specList working");
    // })

    this.specService.viewSpecsByID(this.specId).subscribe(data=>{
      this.currentSpec = data;
    })

    console.log("this is userId:"+this.userId);
    
  }
  
  addReview(){
    console.log("-------------------");
    let review: Review = this.addReviewForm.value;
    review.specs = {...this.specList.filter(specs => specs.specsId == this.addReviewForm.value.specs)[0]};
    review.subject = review.specs.name;
    console.log("-------------------");
    this.date = new Date();
    review.dateCreated = this.date;
    review.customer = this.customer;
    review.specs = this.currentSpec;
    console.log("review spec:",review);
    this.cartService.addReview(review, this.customer.customerId).subscribe(data=>{
      this.router.navigateByUrl('/spec/review/'+this.currentSpec.specsId);
      console.log("working");
      
    });
  }

 
  countStar(star:number) {
    this.selectedValue = star;
  }

}




















































