import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Order } from 'src/app/models/order.model';
import { Specs } from 'src/app/models/specs.model';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})
export class ViewOrdersComponent implements OnInit {

  orders:Order[]=[];
  specs:Specs[]=[];
  userId:number;
  // m : any;

  constructor(private service:OrderService,private route:ActivatedRoute) { }

  
  
  ngOnInit(): void {
    this.userId= this.route.snapshot.params['id'];
    this.getOrders();
    // this.m =this.orders[0].specs[1].name
  }
  
  
  
  getOrders(){
    // this.service.getOrderby_userId(this.userId).subscribe(data=>{
    //   this.orders=data;
    //   console.log(this.orders);
    // })

    this.service.viewAllOrders().subscribe(data=>{
      this.orders = data;
      console.log(this.orders);
    });
  }
  

  

}
