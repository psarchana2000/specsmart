import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from 'src/app/models/cart.model';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { SpecsService } from 'src/app/services/specs.service';

@Component({
  selector: 'app-customer-view-specs',
  templateUrl: './customer-view-specs.component.html',
  styleUrls: ['./customer-view-specs.component.css']
})
export class CustomerViewSpecsComponent implements OnInit {

  specs:Specs[]=[];
  newSpecs : Specs[]=[];
  searchData : string=""; 
  cart:Cart;
  userId:number=0;
  carId:number=0;
  specsId:number;

  constructor(private specsService:SpecsService,private cartService:CartService,private route:ActivatedRoute,private router:Router) {

  }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    
    console.log("user id : "+this.userId);
    this.cartService.getCartByUserId(this.userId).subscribe(data=>{
      console.log( "data : "+ data.cartId);
      this.cart = data;
      console.log(this.cart);
    })


    this.specsService.viewAllSpecs().subscribe(data=>{
      console.log(data);
      this.specs=data;
      this.newSpecs = data;
    })
  }

  search(){
    console.log()
    this.specs = this.newSpecs.filter((data) => {
      if(data.category.toLowerCase().includes(this.searchData.toLowerCase())){
        return data;
      }
    })
  }
  
  sortByPrice(sortBy : number){
    console.log(sortBy);
    if(sortBy == 1){
      this.specs = this.newSpecs.sort((s1,s2) => {
        if(s1.price > s2.price){
            return 1;
        }else if(s1.price < s2.price){
          return -1;
        }else{
          return 0;
        }
      })
    }else if(sortBy == 2){
      this.specs = this.newSpecs.sort((s1,s2) => {
        if(s1.price < s2.price){
            return 1;
        }else if(s1.price > s2.price){
          return -1;
        }else{
          return 0;
        }
      })

    }else{
      console.log(this.newSpecs);
      this.viewAllSpecs();
    }

  }

  public viewAllSpecs(){
    this.specsService.viewAllSpecs().subscribe(data=>{
      this.specs=data;
      this.newSpecs = data;
    })
  }
  

  public addSpecsToCart(specs:Specs){
    
    console.log(specs.specsId);
    this.cartService.addSpecsToCart(this.cart.cartId,specs.specsId).subscribe(data=>{
      // this.router.navigate(['/my-cart/'+this.cart.cartId]);
      alert("Added to the cart.");
    })
  }




}
