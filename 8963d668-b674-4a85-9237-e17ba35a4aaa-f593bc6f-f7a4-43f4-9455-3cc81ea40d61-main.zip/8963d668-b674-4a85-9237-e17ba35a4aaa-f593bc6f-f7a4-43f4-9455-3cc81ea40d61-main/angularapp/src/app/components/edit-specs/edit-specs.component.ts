import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Specs } from 'src/app/models/specs.model';
import { SpecsService } from 'src/app/services/specs.service';

@Component({
  selector: 'app-edit-specs',
  templateUrl: './edit-specs.component.html',
  styleUrls: ['./edit-specs.component.css']
})
export class EditSpecsComponent implements OnInit {

  editSpec : Specs={
    "name": "",
    "category" : "",
    "imageUrl": "",
    "description": "",
    "price": 0,
    "quantity" : 0

  };
  //editSpec : Specs={};
  editId : number;
  editForm : FormGroup;

  constructor(private specsService:SpecsService,private builder:FormBuilder,private route:ActivatedRoute,private router:Router) {
    this.editForm=builder.group({
      name : builder.control("",Validators.required),
    category : builder.control("",Validators.required),
    description : builder.control("",Validators.required),
    price : builder.control("",Validators.required),
    quantity : builder.control("",Validators.required),
    imageUrl : builder.control("",Validators.required)
    })
   }

  ngOnInit(): void {
    this.editId = this.route.snapshot.params['specsId'];

    console.log(this.editId);


    this.specsService.viewSpecsByID(this.editId).subscribe(data=>{
      console.log(data);
      this.editSpec=data;
      console.log(this.editSpec);
    })
  }

  

  public editSpecs(){
    if(this.editForm.valid){
      this.specsService.updateSpecs(this.editId,this.editSpec).subscribe(data=>{
        alert("Specs Edited Successfully!");
        this.router.navigate(["/api/specs/view"]);
         
      })

    }
  }
  public get name(){
    return this.editForm.get("name");
  }
  public get category(){
    return this.editForm.get("category");
  }
  public get description(){
    return this.editForm.get("description");
  }
  public get price(){
    return this.editForm.get("price");
  }
  public get quantity(){
    return this.editForm.get("quantity");
  }
  public get imageUrl(){
    return this.editForm.get("imageUrl");
  }

}
