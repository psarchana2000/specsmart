import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Order } from 'src/app/models/order.model';
import { Specs } from 'src/app/models/specs.model';
import { CartService } from 'src/app/services/cart.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit {

  constructor(private service:OrderService,private cartService:CartService,private router:ActivatedRoute) { }
  specs:Specs[]=[];

  orders : Order[] = [];

  id:number=0;

  ngOnInit(): void {
    this.id = this.router.snapshot.params['id'];
    console.log("Id to fetch : "+this.id)
    this.getOrder();

  }

    getOrder(){
        this.service.getOrderby_userId(this.id).subscribe(data=>{
            this.orders = data;
            console.log(this.orders)
        });
        
    } 
    
    

        
        

       
   

       

    


    

  
  
  


}