
export class Global{


    public static apiUrl : string  = "https://ide-fececdfeddcadeabbdeceaafdfbcffafccead.premiumproject.examly.io/proxy/8080";


}

