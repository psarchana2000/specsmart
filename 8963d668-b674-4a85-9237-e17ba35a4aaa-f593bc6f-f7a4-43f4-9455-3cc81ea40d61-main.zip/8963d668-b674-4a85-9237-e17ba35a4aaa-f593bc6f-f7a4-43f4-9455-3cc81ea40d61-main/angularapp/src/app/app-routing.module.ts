import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';

import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { AddSpecsComponent } from './components/add-specs/add-specs.component';
import { ViewSpecsComponent } from './components/view-specs/view-specs.component';
import { EditSpecsComponent } from './components/edit-specs/edit-specs.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CustomerdashboardComponent } from './components/customerdashboard/customerdashboard.component';
import { MyCartComponent } from './components/my-cart/my-cart.component';

import { ViewOrdersComponent } from './components/view-orders/view-orders.component';

import { PlaceOrderComponent } from './components/place-order/place-order.component';

import { CustomerViewSpecsComponent } from './components/customer-view-specs/customer-view-specs.component';

import { AddReviewComponent } from './components/add-review/add-review.component';
import { ViewReviewComponent } from './components/view-review/view-review.component';
import { HomeComponent } from './components/home/home.component';


const routes: Routes = [{path:"register",component:RegistrationComponent},
                         {path:"login",component:LoginComponent},
                         {path:"api/specs/add",component:AddSpecsComponent},
                         {path:"api/specs/view",component:ViewSpecsComponent},
                         {path:"api/specs/:specsId",component:EditSpecsComponent},
                         {path:"api/dashboard",component:DashboardComponent},
                         {path:"customerdashboard/:id",component:CustomerdashboardComponent},
                         {path:"dashboard",component:DashboardComponent},                        
                         {path:"api/view-orders/:id", component: ViewOrdersComponent},
                         {path:"place-order/:id", component: PlaceOrderComponent},                 
                         {path:"myorders/:id", component: MyOrdersComponent},
                         {path:"my-cart/:id",component: MyCartComponent},
                         {path:"customer/specs/:id",component: CustomerViewSpecsComponent},
                         {path:"review/:id", component: AddReviewComponent},
                         {path:"spec/review/:id", component: ViewReviewComponent},
                         {path:"**", component:HomeComponent},
                        ];            

                          






@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
