package com.examly.springapp.exceptions;

public class SpecsNotFoundException extends RuntimeException{
    
}
