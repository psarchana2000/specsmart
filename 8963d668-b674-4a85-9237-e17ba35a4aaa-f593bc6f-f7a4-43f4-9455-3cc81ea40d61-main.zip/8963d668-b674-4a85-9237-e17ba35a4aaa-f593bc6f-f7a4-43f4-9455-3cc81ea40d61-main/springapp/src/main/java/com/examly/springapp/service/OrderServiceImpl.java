package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.CustomerNotFoundException;
import com.examly.springapp.exceptions.OrderNotFoundException;
import com.examly.springapp.model.Customer;
import com.examly.springapp.model.Orders;
import com.examly.springapp.model.Specs;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.OrderRepo;
import com.examly.springapp.repository.SpecsRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class OrderServiceImpl implements OrderService{

    @Autowired 
    private OrderRepo orderRepo;

    @Autowired
    private CustomerRepo customerRepo;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private SpecsRepo specsRepo;

   

   
    

    @Override
    public Orders addOrder(Orders order,Long customer_id) {
        if(!customerRepo.existsById(customer_id))
        {
            throw new CustomerNotFoundException();
        }
        Customer customer = customerRepo.findById(customer_id).get();
        order.setCustomer(customer);
        for(Specs s : order.getSpecs()){ 
            int quantity = s.getQuantity();
            s.setQuantity(--quantity);
            specsRepo.save(s);
        }
        return  orderRepo.save(order);
        
    }

    @Override
    public List<Orders> getAllOrders() {
       return orderRepo.findAll();
        
    }

    @Override
    public Orders getOrderById(Long orderId) {
       if(orderRepo.existsById(orderId)){
         Orders zn = orderRepo.findById(orderId).get();
         return zn;
        }
       else{
        throw new OrderNotFoundException();
       }
    }

    @Override
    public List<Orders> getOrdersByCustomerId(Long customerId) {
       if(customerRepo.existsById(customerId)){

            Customer customer= customerRepo.findById(customerId).get();
            return  orderRepo.findByCustomer(customer);
            

       }else{
        throw new OrderNotFoundException();
       }
    }

    @Override
    public List<Orders> getOrdersByUserId(Long userId) {
        if(userRepo.existsById(userId)){
            User user = userRepo.findById(userId).get();
            Customer customer = customerRepo.findByUser(user);
           
            return orderRepo.findByCustomer(customer);
            
        }else{
            throw new OrderNotFoundException();
        }
        
    }
    
}
