package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.OrderNotFoundException;
import com.examly.springapp.model.Orders;
import com.examly.springapp.service.OrderService;

@RestController

public class OrderController {
    
    @Autowired
    private OrderService orderservice;

    
    @PostMapping("/api/order/{customer_Id}")
     @PreAuthorize("permitAll()")
    public ResponseEntity<?> AddOrder(@RequestBody Orders order,@PathVariable Long customer_Id){
        try {
            return ResponseEntity.status(201).body(orderservice.addOrder(order,customer_Id));
        } catch (OrderNotFoundException e) {
            return ResponseEntity.status(500).body("Cannot Add");
        }
    }
    @GetMapping("/api/order")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> ViewAllOrders(){
        try {
            return ResponseEntity.status(200).body(orderservice.getAllOrders());
        } catch (OrderNotFoundException e) {
            return ResponseEntity.status(500).body("Order Not Found");
        }
    }
    @GetMapping("/api/order/{orderId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> ViewOrderby_OrderId(@PathVariable Long orderId){
        try {
            return ResponseEntity.status(200).body(orderservice.getOrderById(orderId));
        } catch (OrderNotFoundException e) {
            return ResponseEntity.status(500).body("order not found");
        }
    }
    @GetMapping("/api/order/customer/{customerId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> ViewOrderby_CustomerId(@PathVariable Long customerId){
        try {
            return ResponseEntity.status(200).body(orderservice.getOrdersByCustomerId(customerId));
        } catch (OrderNotFoundException e) {
            return ResponseEntity.status(500).body("Order not Found");
        }
    }
    @GetMapping("/api/order/user/{UserId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> ViewOrderby_UserId(@PathVariable Long UserId){
        try {
            return ResponseEntity.status(200).body(orderservice.getOrdersByUserId(UserId));
        } catch (OrderNotFoundException e) {
            return ResponseEntity.status(500).body("Order Not found");
        }
    }
}

