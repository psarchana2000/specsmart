package com.examly.springapp.exceptions;

public class NoReviewFoundException extends RuntimeException{
    
}
