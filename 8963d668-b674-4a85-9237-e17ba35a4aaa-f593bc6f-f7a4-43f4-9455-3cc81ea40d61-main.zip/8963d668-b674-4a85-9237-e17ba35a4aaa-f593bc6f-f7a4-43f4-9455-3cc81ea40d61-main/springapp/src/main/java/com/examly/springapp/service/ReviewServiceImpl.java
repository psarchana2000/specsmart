package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.NoReviewFoundException;
import com.examly.springapp.exceptions.ReviewIdNotFoundException;
import com.examly.springapp.model.Customer;
import com.examly.springapp.model.Review;
import com.examly.springapp.model.Specs;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.CustomerRepo;
//import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.ReviewRepo;
import com.examly.springapp.repository.SpecsRepo;
//import com.examly.springapp.repository.UserRepo;
import com.examly.springapp.repository.UserRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ReviewServiceImpl implements ReviewService{

    @Autowired
    private ReviewRepo reviewRepo;

    @Autowired
    private CustomerRepo customerRepo;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private SpecsRepo specsRepo;

    @Override
    public Review addReview(Review review,Long customerId){
        //need to check for which customer the review is getting added
        
        if(customerRepo.existsById(customerId)){
            Customer customer=customerRepo.findById(customerId).get();
            review.setCustomer(customer);
            return reviewRepo.save(review);
        }
        return null;
    }

    @Override
    public Review getReviewById(int reviewId) {
        if(reviewRepo.existsById(reviewId)){
            Optional<Review> optional = reviewRepo.findById(reviewId);
            return optional.get();
        }else{
            throw new NoReviewFoundException();
        }
    }

    @Override
    public List<Review> getAllReview() {
        return reviewRepo.findAll();
    }

    // @Override
     public List<Review> getReviewByUserID(Long userId) {
    //      //user>customer>review
    //     return reviewRepo.findByUserId(userId);
    //    //Customer customer = customerRepo.findByUser(user);
        
        if(userRepo.existsById(userId)){
            User user = userRepo.findById(userId).get();
            if(!customerRepo.existsByUser(user)){
                throw new EntityNotFoundException();
            }
            Customer customer = customerRepo.findByUser(user);
            return reviewRepo.findByCustomer(customer);
        }

          throw new EntityNotFoundException();
      }

    @Override
    public void deleteReview(int reviewId) {
       if(reviewRepo.existsById(reviewId)){
         reviewRepo.deleteById(reviewId);
       }else{
        throw new ReviewIdNotFoundException();
       }
    }

    @Override
    public List<Review> getReviewsBySpec(Long specsId) {
        Optional<Specs> specsOpt = specsRepo.findById(specsId);        
        return reviewRepo.findBySpecs(specsOpt.get());
    }
    

}
