package com.examly.springapp.service;

import java.util.List;


import com.examly.springapp.model.Review;
import com.examly.springapp.model.Specs;

public interface ReviewService {

    public Review addReview(Review review,Long customerId);
    public Review getReviewById(int reviewId);
    public List<Review> getAllReview();
    public List<Review> getReviewByUserID(Long userId);
    public void deleteReview(int reviewId);
    public List<Review> getReviewsBySpec(Long specsId);
}
