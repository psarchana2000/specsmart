package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Specs;

public interface SpecsService {
  public Specs addSpecs(Specs specs);
  public List<Specs> getAllSpecs();
  public Specs getSpecsById(Long specsId);
  public Specs editSpecs(Long specsId, Specs updatedSpecs);
  public void deleteSpecs(Long specsId);

}
