package com.examly.springapp.exceptions;

public class CustomerNotFoundException extends RuntimeException{

}
