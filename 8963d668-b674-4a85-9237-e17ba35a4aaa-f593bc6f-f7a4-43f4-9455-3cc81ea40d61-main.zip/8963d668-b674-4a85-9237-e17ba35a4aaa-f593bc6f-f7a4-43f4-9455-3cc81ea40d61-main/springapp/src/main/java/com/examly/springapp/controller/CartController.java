package com.examly.springapp.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.CartNotFoundException;
import com.examly.springapp.model.Cart;
import com.examly.springapp.service.CartService;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin

public class CartController {
    
    @Autowired private CartService cartService;

    @PostMapping
    public ResponseEntity<?>  addCart(@RequestBody Cart cart){
        try{

            Cart addedCart = cartService.addCart(cart);
            return ResponseEntity.status(201).body(addedCart);
        }catch(CartNotFoundException e){
            return ResponseEntity.status(500).body("cart not found");
        }
    }

    @PostMapping("/{cartId}/specs/{specsId}")
     @PreAuthorize("permitAll()")
    public ResponseEntity<?>  addSpecsToCart(@PathVariable Long specsId,@PathVariable Long cartId){
        try{
            Cart addedCart = cartService.addSpecsToCart(specsId,cartId);
            return ResponseEntity.status(201).body(addedCart);
        }catch(CartNotFoundException e){
            return ResponseEntity.status(500).body("Cart Not Found");
        }
    }

    @PutMapping("/{id}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?>  editCart(@PathVariable Long id,@RequestBody Cart cart){
        try{
            Cart editedCart = cartService.editCart(id,cart);
            return ResponseEntity.status(200).body(editedCart);
        }catch(CartNotFoundException e){
            return ResponseEntity.status(500).body("Cart not Found");
        }
    }

    @GetMapping("/customer/{id}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?>  viewCartByCustomerId(@PathVariable Long id){
        try{
            Cart cart = cartService.getCartByCustomerId(id);
            return ResponseEntity.status(200).body(cart);
        }catch(CartNotFoundException e){
            return ResponseEntity.status(404).body("Cart not found");
        }
    }
    @GetMapping("/user/{id}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?>  viewCartByUserId(@PathVariable Long id){
        try{
           
            Cart cart = cartService.getCartByUserId(id);
            return ResponseEntity.status(200).body(cart);
        }catch(CartNotFoundException e){
            return ResponseEntity.status(404).body("Cart Not found");
        }
    }

    @DeleteMapping("/{cartId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> removeAllSpecs(@PathVariable Long cartId){
        try{
            return ResponseEntity.status(200).body(cartService.removeAllSpecs(cartId));
        }catch(Exception e){
            return ResponseEntity.status(500).body("Delete Specs failed");
            
        }
    }

    @DeleteMapping("/{cartId}/specs/{specsId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> removeSpecsById(@PathVariable Long cartId,@PathVariable long specsId){
        try{
            

            return ResponseEntity.status(200).body(cartService.removeSpecsFromCart(cartId,specsId));
        }catch(Exception e){
            return ResponseEntity.status(500).body("Delete Spec Failed");
            
        }
    }   

    @DeleteMapping("/specs/{specsId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> removeSpecs(@PathVariable long specsId){
        try{
            return ResponseEntity.status(200).body(cartService.removeSpecs(specsId));
        }catch(Exception e){
            return ResponseEntity.status(500).body("Delete Specs Failed");
            
        }
    }   
}