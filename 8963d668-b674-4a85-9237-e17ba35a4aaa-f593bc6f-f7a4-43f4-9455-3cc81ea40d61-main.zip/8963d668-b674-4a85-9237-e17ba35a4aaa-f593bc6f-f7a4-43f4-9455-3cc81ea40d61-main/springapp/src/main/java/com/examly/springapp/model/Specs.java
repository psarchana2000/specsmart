package com.examly.springapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Specs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long specsId;
    private String name;
    private String category;
    private String imageUrl;
    private String description;
    private double price;
    private int quantity;

    public Specs() {
    }

  

    public Specs(Long specsId, String name, String category, String imageUrl, String description, double price,
            int quantity) {
        this.specsId = specsId;
        this.name = name;
        this.category = category;
        this.imageUrl = imageUrl;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
    }



    public Long getSpecsId() {
        return specsId;
    }



    public void setSpecsId(Long specsId) {
        this.specsId = specsId;
    }



    public String getName() {
        return name;
    }



    public void setName(String name) {
        this.name = name;
    }



    public String getCategory() {
        return category;
    }



    public void setCategory(String category) {
        this.category = category;
    }



    public String getImageUrl() {
        return imageUrl;
    }



    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }



    public String getDescription() {
        return description;
    }



    public void setDescription(String description) {
        this.description = description;
    }



    public double getPrice() {
        return price;
    }



    public void setPrice(double price) {
        this.price = price;
    }



    public int getQuantity() {
        return quantity;
    }



    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }



    @Override
    public String toString() {
        return "Specs [specsId=" + specsId + ", name=" + name + ", category=" + category + ", imageUrl=" + imageUrl
                + ", description=" + description + ", price=" + price + ", quantity=" + quantity + "]";
    }  

    
    
    
}
