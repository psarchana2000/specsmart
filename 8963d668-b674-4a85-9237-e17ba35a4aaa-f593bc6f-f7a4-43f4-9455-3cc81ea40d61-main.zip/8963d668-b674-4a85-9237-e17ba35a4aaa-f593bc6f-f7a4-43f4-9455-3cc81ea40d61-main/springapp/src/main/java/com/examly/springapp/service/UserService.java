package com.examly.springapp.service;

import com.examly.springapp.DTO.LoginRequestDto;
import com.examly.springapp.model.User;

public interface UserService {


    public User RegisterUser(User user);
   // public User loginUser(LoginDto user);
    public User getUser(String email);
    public User getUserById(long userId);

}
