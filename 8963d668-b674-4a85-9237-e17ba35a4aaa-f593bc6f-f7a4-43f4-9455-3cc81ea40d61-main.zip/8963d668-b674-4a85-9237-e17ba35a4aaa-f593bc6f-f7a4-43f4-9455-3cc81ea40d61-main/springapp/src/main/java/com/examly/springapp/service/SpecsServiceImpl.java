package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.CartNotFoundException;
import com.examly.springapp.exceptions.SpecsAlreadyExistsException;
import com.examly.springapp.exceptions.SpecsNotFoundException;
import com.examly.springapp.model.Cart;
import com.examly.springapp.model.Specs;
import com.examly.springapp.repository.CartRepo;
import com.examly.springapp.repository.SpecsRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class SpecsServiceImpl implements SpecsService{

    @Autowired
    private SpecsRepo specsRepo;
    @Autowired
    private CartRepo cartRepo;

    @Override
    public Specs addSpecs(Specs specs) {
        if(specsRepo.existsByName(specs.getName())){
            throw new SpecsAlreadyExistsException();
        }else{
            return specsRepo.save(specs);    
        }
    }

    @Override
    public List<Specs> getAllSpecs() {
        return specsRepo.findAll();
    }

    @Override
    public Specs editSpecs(Long specsId, Specs updatedSpecs) {
        if(specsRepo.existsById(specsId)){
           // Optional<Specs> specs = specsRepo.findById(specsId);
            updatedSpecs.setSpecsId(specsId);
            return specsRepo.save(updatedSpecs); 
        }else{
            throw new SpecsNotFoundException();
        }
    }
    
    @Override
    public void deleteSpecs(Long specsId) {
        if(!specsRepo.existsById(specsId)){
            throw new SpecsNotFoundException();
        }
            List<Cart> carts = cartRepo.findAll();
            for(Cart cart : carts){
                List<Specs> specs = cart.getSpecs();
                for(int i=0;i<specs.size();i++){
                    if(specs.get(i).getSpecsId() == specsId){
                        specs.remove(specs.get(i));
                    }
                }
                
                    cartRepo.save(cart);
            }

            specsRepo.deleteById(specsId);
       
    }

    @Override
    public Specs getSpecsById(Long specsId) {
        if(specsRepo.existsById(specsId)){
            Optional<Specs> optional = specsRepo.findById(specsId);
            return optional.get();
        }else{
            throw new SpecsNotFoundException();
        }
    }
    
    
}
