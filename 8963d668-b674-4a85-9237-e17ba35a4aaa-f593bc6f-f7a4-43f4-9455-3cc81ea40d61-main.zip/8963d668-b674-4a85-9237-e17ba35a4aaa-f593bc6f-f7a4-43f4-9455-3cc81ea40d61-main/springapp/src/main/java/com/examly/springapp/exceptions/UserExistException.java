package com.examly.springapp.exceptions;

public class UserExistException extends RuntimeException{
    
}
