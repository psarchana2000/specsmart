package com.examly.springapp.exceptions;

public class OrderNotFoundException extends RuntimeException{

}
