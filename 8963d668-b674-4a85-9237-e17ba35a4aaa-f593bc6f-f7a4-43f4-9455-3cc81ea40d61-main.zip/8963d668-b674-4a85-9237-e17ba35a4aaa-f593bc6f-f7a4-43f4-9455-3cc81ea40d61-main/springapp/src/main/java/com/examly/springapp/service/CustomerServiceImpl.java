package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.CustomerNotFoundException;
import com.examly.springapp.model.Customer;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    private CustomerRepo customerRepo;

    @Autowired
    private UserRepo userRepo;

    @Override
    public Customer registerCustomer(Customer customer) {
        System.out.println("----------------------------------------------");
        System.out.println("------------customer : "+customer);
        System.out.println("----------------------------------------------");
        return customerRepo.save(customer);
    }

    @Override
    public Customer getCustomerById(Long customerId) {
    
        if(customerRepo.existsById(customerId)){
            Optional<Customer> opt = customerRepo.findById(customerId);
            return opt.get();
        }
        else throw new CustomerNotFoundException();
    }

    @Override
    public List<Customer> getAllCustomer() {
        List<Customer> list = customerRepo.findAll();
        if(list.isEmpty()){
            throw new CustomerNotFoundException();
        }
        else return list;
    }

    // @Override
    // public Customer getCustomerByUserId(Long userId) {
    //     // TODO Auto-generated method stub
    //     throw new UnsupportedOperationException("Unimplemented method 'getCustomerByUserId'");
    // }

    @Override
    public Customer getCustomerByUserId(Long userId) {
        Optional<User> optUser = userRepo.findById(userId);
        if(optUser.isPresent()){    
            User user = optUser.get();
            Customer optCustomer = customerRepo.findByUser(user);
            
            if(optCustomer==null){
                throw new CustomerNotFoundException();
            }
            else return optCustomer;
        }
        else{
            throw new CustomerNotFoundException();
        }
    }
    
}
