package com.examly.springapp.model;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;
    private double orderPrice;
    private int quantity;
    private Date orderDate;

    @ManyToMany
    @JoinTable(name="order_specs",joinColumns = @JoinColumn(name="order_id"),inverseJoinColumns = @JoinColumn(name="specs_id"))
    private List<Specs> specs;

    @ManyToOne
    @JoinColumn(name="customer_id")
    private Customer customer;


}