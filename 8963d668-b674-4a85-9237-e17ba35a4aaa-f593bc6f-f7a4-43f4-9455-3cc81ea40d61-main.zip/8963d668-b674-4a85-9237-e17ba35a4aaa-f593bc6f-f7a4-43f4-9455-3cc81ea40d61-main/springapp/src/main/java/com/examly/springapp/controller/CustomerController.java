package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Customer;
import com.examly.springapp.service.CustomerService;

@CrossOrigin()
@RestController

public class CustomerController {

    @Autowired
    private CustomerService customerService;
    
    @PostMapping("/api/customer")
     @PreAuthorize("permitAll()")
    public ResponseEntity<?> registerCustomer(@RequestBody Customer customer){
        return ResponseEntity.status(201).body(customerService.registerCustomer(customer));
    }
    
    @GetMapping("/api/customer")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getAllCustomers(){
        try{
            return ResponseEntity.status(200).body(customerService.getAllCustomer());
        }catch(Exception e){
            return ResponseEntity.status(404).body("no Customers found!");
        }
    }
    
    @GetMapping("/api/customer/user/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getCustomerByUserId(@PathVariable Long userId){
        try{
            return ResponseEntity.status(200).body(customerService.getCustomerByUserId(userId));
        }catch(Exception e){
            return ResponseEntity.status(404).body("No Customers Found!");
        }
        
    }
    
    @GetMapping("/api/customer/{customerId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getCustomerById(@PathVariable long customerId){
        try{
            return ResponseEntity.status(200).body(customerService.getCustomerById(customerId));
        }catch(Exception e){
            return ResponseEntity.status(404).body("No customers found!");
        }
        
    }
  
}