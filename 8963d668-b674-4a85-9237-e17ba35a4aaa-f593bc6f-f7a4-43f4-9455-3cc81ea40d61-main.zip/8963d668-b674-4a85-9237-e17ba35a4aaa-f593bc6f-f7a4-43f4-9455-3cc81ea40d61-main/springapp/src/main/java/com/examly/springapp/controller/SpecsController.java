package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.SpecsAlreadyExistsException;
import com.examly.springapp.exceptions.SpecsNotFoundException;
import com.examly.springapp.model.Specs;
import com.examly.springapp.service.SpecsService;

@RestController
@CrossOrigin

public class SpecsController {
    @Autowired
    private SpecsService specsService;

    @PostMapping("/api/specs")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> addSpecs(@RequestBody Specs specs){
        try{
           return ResponseEntity.status(201).body(specsService.addSpecs(specs));
        }catch(SpecsAlreadyExistsException e){
           return ResponseEntity.status(500).body("Specs Already Exists.");
        }
    }

    @GetMapping("/api/specs")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getAllSpecs(){
        return ResponseEntity.status(200).body(specsService.getAllSpecs());
    }

    @PutMapping("/api/specs/{specsId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> updateSpecs(@PathVariable Long specsId,@RequestBody Specs updatedSpecs){
        try{
            return ResponseEntity.status(200).body(specsService.editSpecs(specsId, updatedSpecs));
        }catch(SpecsNotFoundException e){
            return ResponseEntity.status(500).body("Specs Not Found.");
        }
    }

    @DeleteMapping("/api/specs/{specsId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> deleteSpecs(@PathVariable Long specsId){
       
        System.out.println("--------------------specId:"+specsId);
       
      
        try{
            specsService.deleteSpecs(specsId);
            System.out.println("delete Succefully");
            return ResponseEntity.status(200).body(true);
        }catch(SpecsNotFoundException e){
            return ResponseEntity.status(500).body(false);
        }
        
    }

    @GetMapping("/api/specs/{specsId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getSpecsById(@PathVariable Long specsId){
        try{
            return ResponseEntity.status(200).body(specsService.getSpecsById(specsId));
        }catch(SpecsNotFoundException e){
            return ResponseEntity.status(500).body(null);
        }
    }
    
}