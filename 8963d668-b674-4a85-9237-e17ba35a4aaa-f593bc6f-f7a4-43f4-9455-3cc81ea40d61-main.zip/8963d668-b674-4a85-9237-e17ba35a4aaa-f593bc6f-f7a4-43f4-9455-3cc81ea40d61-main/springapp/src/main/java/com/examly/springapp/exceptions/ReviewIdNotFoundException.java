package com.examly.springapp.exceptions;

public class ReviewIdNotFoundException extends RuntimeException{
    
}
