package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Cart;
import com.examly.springapp.model.Customer;
import com.examly.springapp.model.User;

@Repository
public interface CustomerRepo extends JpaRepository<Customer,Long>{

    boolean existsByUser(User user);

    Customer findByUser(User user);

    // Optional<Customer> findByUser(User user);





    // @Query("SELECT c FROM Customer c WHERE user_id = ?1")
//     Optional<Customer> findByUser(User user);

    // public boolean existsByCustomerName(String customerName);
    // public Optional<Customer> findByCustomerName(String customerName);

    
    
}
