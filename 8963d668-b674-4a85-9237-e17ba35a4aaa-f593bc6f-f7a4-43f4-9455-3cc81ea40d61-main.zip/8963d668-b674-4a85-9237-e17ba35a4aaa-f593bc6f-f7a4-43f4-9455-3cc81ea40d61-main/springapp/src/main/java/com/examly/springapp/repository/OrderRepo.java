package com.examly.springapp.repository;



import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Customer;
import com.examly.springapp.model.Orders;
@Repository
public interface OrderRepo extends JpaRepository<Orders,Long> {

    // @Query("SELECT o FROM Orders o WHERE customer_id= ?1")
    //  List<Orders> findByCustomerId(Long customerId);

    List<Orders> findByCustomer(Customer customer);


    
}
