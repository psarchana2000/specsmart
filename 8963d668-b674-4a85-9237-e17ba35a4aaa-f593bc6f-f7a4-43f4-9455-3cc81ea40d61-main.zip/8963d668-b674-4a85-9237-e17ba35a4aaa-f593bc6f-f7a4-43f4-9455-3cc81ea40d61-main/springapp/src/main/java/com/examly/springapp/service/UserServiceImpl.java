package com.examly.springapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import com.examly.springapp.DTO.LoginRequestDto;
import com.examly.springapp.exceptions.UserExistException;
import com.examly.springapp.exceptions.UserNotFoundException;

import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

@Service
public class UserServiceImpl  implements UserService{
 
    @Autowired
    private UserRepo userrepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User RegisterUser(User user) {
        User existsUser=userrepo.findByUsername(user.getUsername()).orElse(null);
        if(existsUser !=null)
        {
            throw new UserExistException();        
        }
       user.setPassword(passwordEncoder.encode(user.getPassword()));
       
       return userrepo.save(user);
    
    }

    // @Override
    // public User loginUser(LoginDto user) {
    //     User fetchUser=userrepo.findByUsername(user.getUsername()).orElse(null);
    //     return fetchUser;
    // }

    public User getUser(String email){
        return userrepo.findByEmail(email).orElse(null);
    }
    @Override
    public User getUserById(long userId) {
        Optional<User> opt = userrepo.findById(userId);
        if(opt.isEmpty()){
            throw new UserNotFoundException();
        }
        else return opt.get();
    }
}
