package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.CartNotFoundException;
import com.examly.springapp.exceptions.CustomerNotFoundException;
import com.examly.springapp.exceptions.SpecsNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Cart;
import com.examly.springapp.model.Customer;
import com.examly.springapp.model.Specs;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.CartRepo;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.SpecsRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class CartServiceImpl implements CartService {

    @Autowired private CartRepo cartRepo;
    @Autowired private SpecsRepo specsRepo;
    @Autowired private CustomerRepo customerRepo;
    @Autowired private UserRepo userRepo;


    @Override
    public Cart addCart(Cart cart) {
        return cartRepo.save(cart);
    }

    @Override
    public Cart editCart(Long cartId, Cart updatedCart) {
        if(!cartRepo.existsById(cartId)){
            throw new CartNotFoundException();
        }
        Optional<Cart> optionalCart = cartRepo.findById(cartId);
        if(optionalCart.isEmpty()){
            throw new CartNotFoundException();
        }
        Cart oldCart = optionalCart.get();
        oldCart.setCustomer(updatedCart.getCustomer());
        oldCart.setSpecs(updatedCart.getSpecs());
        oldCart.setTotalAmount(updatedCart.getTotalAmount()); 
        return cartRepo.save(oldCart);       
    }

    @Override
    public Cart removeSpecsFromCart(Long cartId, Long specsId) {
        
        if(!cartRepo.existsById(cartId)){
            throw new CartNotFoundException();
        }
        if(!specsRepo.existsById(specsId)){
            throw new CartNotFoundException();
        }
        Cart cart = cartRepo.findById(cartId).get();
        Specs spec = specsRepo.findById(specsId).get();
        cart.getSpecs().remove(spec);
        double totalAmount = cart.getTotalAmount()-spec.getPrice();
        cart.setTotalAmount(totalAmount);
        cartRepo.save(cart);
        return cart;        
    }

    @Override
    public Cart removeAllSpecs(Long cartId) {
        if(!cartRepo.existsById(cartId)){
            throw new CartNotFoundException();
        }
        Cart cart = cartRepo.findById(cartId).get();
        cart.getSpecs().removeAll(cart.getSpecs());
        cart.setTotalAmount(0); 
        return cartRepo.save(cart);
    }

    @Override
    public Cart getCartByCustomerId(Long customerId) {
        if(!customerRepo.existsById(customerId)){
            throw new CustomerNotFoundException();
        }
        Customer customer = customerRepo.findById(customerId).orElse(null);  
        return cartRepo.findByCustomer(customer);
    }

    @Override
    public Cart getCartByUserId(Long userId) {
        if(!userRepo.existsById(userId)){
            throw new UserNotFoundException();
        }
        User user = userRepo.findById(userId).orElse(null);

        if(!customerRepo.existsByUser(user)){
            throw new CustomerNotFoundException();
        }
        Customer customer = customerRepo.findByUser(user);

        System.out.println("=========================================");
        System.out.println("===================user id :  "+ userId + "custmer id : "+ customer.getCustomerId());
        System.out.println("=========================================");

        return cartRepo.findByCustomer(customer);
    }

    @Override
    public Cart addSpecsToCart(Long specsId, Long cartId) {
        if(!specsRepo.existsById(specsId)){
            throw new SpecsNotFoundException();
        }
        if(!cartRepo.existsById(cartId)){
            throw new CartNotFoundException();
        }
        Specs specs = specsRepo.findById(specsId).get();
        Cart cart = cartRepo.findById(cartId).get();
        cart.getSpecs().add(specs);
        double totalAmount = cart.getTotalAmount()+specs.getPrice();
        cart.setTotalAmount(totalAmount);
        
        return cartRepo.save(cart);
    }

	@Override
	public boolean removeSpecs(long specsId) {
        List<Cart> cartList = cartRepo.findAll();
        for(Cart cart : cartList){
            if(!specsRepo.existsById(specsId)){
                throw new SpecsNotFoundException();
            }
            Specs specs = specsRepo.findById(specsId).get();
            cart.getSpecs().remove(specs);
            cartRepo.save(cart);
        }

        return true;
        

	}

    

    


    


    
    
}
