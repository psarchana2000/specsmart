package com.examly.springapp.exceptions;

public class SpecsAlreadyExistsException extends RuntimeException{
    
}
