package com.examly.springapp.exceptions;

public class UserNotFoundException extends RuntimeException{
    
}
