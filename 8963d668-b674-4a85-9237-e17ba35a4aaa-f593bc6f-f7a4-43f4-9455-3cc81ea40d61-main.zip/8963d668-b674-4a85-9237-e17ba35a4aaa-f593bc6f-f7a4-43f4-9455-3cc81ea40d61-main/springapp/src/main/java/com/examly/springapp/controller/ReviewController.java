package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.ReviewIdNotFoundException;
import com.examly.springapp.model.Review;
import com.examly.springapp.service.ReviewService;

@CrossOrigin()
@RestController
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping("/api/review/{customerId}")
     @PreAuthorize("permitAll()")
    public ResponseEntity<?> addReview(@RequestBody Review review,@PathVariable Long customerId){
        return ResponseEntity.status(201).body(reviewService.addReview(review,customerId));
    }

    @GetMapping("/api/review")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getAllReview(){
        return ResponseEntity.status(200).body(reviewService.getAllReview());
    }



    @DeleteMapping("/api/review/{reviewId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> deleteReview(@PathVariable int reviewId){
        try{
            reviewService.deleteReview(reviewId);
            return ResponseEntity.status(200).body("Review Deleted Successfully.");
        }catch(ReviewIdNotFoundException e){
            return ResponseEntity.status(500).body(null);
        }
    }

    @GetMapping("/api/review/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getAllReviewsByUserId(@PathVariable Long userId){
        return ResponseEntity.status(200).body(reviewService.getReviewByUserID(userId));
    }

    @GetMapping("/api/spec/review/{specsId}")
    public ResponseEntity<?> getReviewsBySpecs(@PathVariable Long specsId){
       
        System.out.println("=========================== SPecs : "+specsId);
        
        return ResponseEntity.status(200).body(reviewService.getReviewsBySpec(specsId));
    }
}