package com.examly.springapp.service;

import com.examly.springapp.model.Cart;

public interface CartService {

    Cart addCart(Cart cart);
    Cart editCart(Long cartId,Cart updatedCart);
    Cart removeSpecsFromCart(Long cartId,Long specsId);
    Cart removeAllSpecs(Long cartId);
    Cart getCartByCustomerId(Long id);
    Cart getCartByUserId(Long id);
    Cart addSpecsToCart(Long specsId, Long cartId);
    boolean removeSpecs(long specsId);
    
    
}
